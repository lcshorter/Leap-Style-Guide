WRMCB=function(e){var c=console;if(c&&c.log&&c.error){c.log('Error running batched script.');c.error(e);}}
;
try {
/* module-key = 'confluence.macros.multimedia:macro-browser-smart-fields', location = 'javascript/macro-fields.js' */
(function(a){AJS.MacroBrowser.activateSmartFieldsAttachmentsOnPage("multimedia",["swf","avi","mov","mp4","mpeg","mpg","wmv","wma","mp3","ram","rm"])})(AJS.$);
}catch(e){WRMCB(e)};