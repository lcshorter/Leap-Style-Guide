WRMCB=function(e){var c=console;if(c&&c.log&&c.error){c.log('Error running batched script.');c.error(e);}}
;
try {
/* module-key = 'com.atlassian.confluence.keyboardshortcuts:confluence-tinymce-keyboard-shortcuts', location = 'js/tinymce-plugin.js' */
define("confluence-keyboard-shortcuts/tinymce-plugin",["ajs","confluence-keyboard-shortcuts/confluence-keyboard-shortcuts"],function(e,b){return{init:function(a){e.debug("Init Editor Keyboard shortcuts plugin");for(var c=function(b){return function(){a.execCommand("FormatBlock",!1,b)}},d=1;7>d;d++)a.addCommand("FormatBlock-h"+d,c("h"+d));a.addCommand("FormatBlock-p",c("p"));a.addCommand("FormatBlock-pre",c("pre"));a.addCommand("FormatBlock-blockquote",c("blockquote"));a.addCommand("mceConfShortcutDialog",
b.keyboardShortcuts.openDialog);a.addButton("help",{title:"confluence.conf_shortcuts_help_desc",cmd:"mceConfShortcutDialog"})},getInfo:function(){var a=require("tinymce");return{longname:"Atlassian Editor Keyboard Shortcuts Plugin",author:"Atlassian",authorurl:"http://www.atlassian.com",version:a.majorVersion+"."+a.minorVersion}}}});
require("confluence/module-exporter").safeRequire("confluence-keyboard-shortcuts/tinymce-plugin",function(e){var b=require("tinymce");b.create("tinymce.plugins.KeyboardShortcutsPlugin",e);b.PluginManager.add("keyboardshortcuts",b.plugins.KeyboardShortcutsPlugin)});
}catch(e){WRMCB(e)};