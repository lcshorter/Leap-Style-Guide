WRMCB=function(e){var c=console;if(c&&c.log&&c.error){c.log('Error running batched script.');c.error(e);}}
;
try {
/* module-key = 'com.atlassian.confluence.editor:editor-support-util', location = 'support/atlassian-editor-support.js' */
define("confluence-editor/support/atlassian-editor-support",["ajs","confluence/meta"],function(c,b){return{inlineTasks:function(){var a=b.get("use-inline-tasks");return"true"===a||!0===a},isCollaborativeContentType:function(){var a=b.get("content-type");return b.get("collaborative-content")&&("page"===a||"blogpost"===a)}}});require("confluence/module-exporter").exportModuleAsGlobal("confluence-editor/support/atlassian-editor-support","AJS.Rte.Support");
}catch(e){WRMCB(e)};